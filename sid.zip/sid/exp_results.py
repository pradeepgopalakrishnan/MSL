import matplotlib.pyplot as plt
import pickle
import numpy as np
import argparse

def moving_average(a, n=3):
  ret = np.cumsum(a, dtype=float)
  ret[n:] = ret[n:] - ret[:-n]
  return ret[n - 1:] / n

def plotter(exp_dict, ep_indices, plot_path, exp_id_list, train_plot_name ,test_plot_name ):
  for exp in exp_id_list:
  	plt.plot( ep_indices, exp_dict[exp]["sampled_train_data"] )
  
  legends = []
  for exp in exp_id_list:
  	legends.append( exp + " " + exp_dict[exp]["exploration_type"] + " R.A.: " + str(round(exp_dict[exp]["relative_test_area"][0],5)))

  plt.legend(legends)
  plt.title("horizon: " + str(exp_dict["E1"]["horizon"]) + ", total_timesteps: " + str(exp_dict["E1"]["total_timesteps"]) )
  plt.ylabel("Total returns per episode")
  plt.xlabel("Number of episodes of training")
  plt.grid()
  plt.savefig(plot_path + train_plot_name)
  plt.close()

  for exp in exp_id_list:
  	plt.plot( exp_dict[exp]["test_data"][0], exp_dict[exp]["test_data"][1] )
  
  legends = []
  for exp in exp_id_list:
  	legends.append( exp + " " + exp_dict[exp]["exploration_type"] + " R.A.: " + str(round(exp_dict[exp]["relative_test_area"][0],5)))

  plt.legend(legends)
  plt.title("horizon: " + str(exp_dict["E1"]["horizon"]) + ", total_timesteps: " + str(exp_dict["E1"]["total_timesteps"]) )
  plt.ylabel("Total returns per episode")
  plt.xlabel("Number of episodes")
  plt.grid()
  plt.savefig(plot_path + test_plot_name)
  plt.close()


parser = argparse.ArgumentParser()
parser.add_argument("id", type=str, help="bunch path")
args = parser.parse_args()

BUNCH_ID = args.id
BUNCH_PATH = "bunch_" + BUNCH_ID + "/bunch.pkl"

with open( BUNCH_PATH , "rb") as f:
  bunch_data = pickle.load(f)

BUNCH_ID = bunch_data["BUNCH_ID"]
BUNCH_DIR = bunch_data["BUNCH_DIR"]
MODEL_DIR = bunch_data["MODEL_DIR"]
DATA_DIR = bunch_data["DATA_DIR"]
PLOT_DIR = bunch_data["PLOT_DIR"]

exp_dict = bunch_data["exp_dict"]

NUM_DATA_POINTS = 100
N = 3

for exp in exp_dict.keys():

  with open( DATA_DIR + "train_data_" + exp + ".pkl" , "rb") as f:
    exp_dict[exp]["train_data"] = np.array( pickle.load(f) )

  with open( DATA_DIR + "test_data_" + exp + ".pkl" , "rb") as f:
    exp_dict[exp]["test_data"] = np.array( pickle.load(f) )

l = len( exp_dict["E1"]["train_data"] )
ep_indices = np.arange( l )[ N-1: ][ : : int( l / NUM_DATA_POINTS ) ]

for exp in exp_dict.keys():
  exp_dict[exp]["sampled_train_data"] = moving_average( exp_dict[exp]["train_data"], N )[ : : int( l / NUM_DATA_POINTS ) ]
  exp_dict[exp]["test_area"] = np.sum( exp_dict[exp]["test_data"][1] )

reference = "E3"

for exp in exp_dict.keys():
  exp_dict[exp]["relative_test_area"] = exp_dict[exp]["test_area"] / ( exp_dict[reference]["test_area"] * 1.0 )

all_exp_ids = list( exp_dict.keys() )

plotter(exp_dict, ep_indices, PLOT_DIR, all_exp_ids, "comparison_train.png", "comparison_test.png")
for exp in exp_dict.keys():
  plotter(exp_dict, ep_indices, PLOT_DIR, [exp], exp + "_train.png", exp + "_test.png")



