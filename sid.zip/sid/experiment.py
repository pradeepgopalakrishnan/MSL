import gym
from stable_baselines.common.vec_env import DummyVecEnv
from stable_baselines.deepq.policies import MlpPolicy
from dqn import DQN
import gridenv
import pickle
import argparse

parser = argparse.ArgumentParser()
parser.add_argument("id", type=str, help="bunch path")
args = parser.parse_args()

BUNCH_ID = args.id
BUNCH_PATH = "bunch_" + BUNCH_ID + "/bunch.pkl"

with open( BUNCH_PATH , "rb") as f:
  bunch_data = pickle.load(f)

BUNCH_ID = bunch_data["BUNCH_ID"]
BUNCH_DIR = bunch_data["BUNCH_DIR"]
MODEL_DIR = bunch_data["MODEL_DIR"]
DATA_DIR = bunch_data["DATA_DIR"]
PLOT_DIR = bunch_data["PLOT_DIR"]

exp_dict = bunch_data["exp_dict"]

for exp in exp_dict.keys():

  print( "Begin Experiment: " + exp_dict[exp]["id"] )

  env = gym.make(exp_dict[exp]["room_name"]+"-v0", horizon = exp_dict[exp]["horizon"] )
  env = DummyVecEnv([lambda: env])

  model = DQN(MlpPolicy, env, verbose=1, horizon = exp_dict[exp]["horizon"], exploration_type = exp_dict[exp]["exploration_type"],
  	exp_id = exp_dict[exp]["id"], data_dir = DATA_DIR, room_name = "OneRoom-v0", num_test_points = 100)
  model.learn(total_timesteps = exp_dict[exp]["total_timesteps"] )

  model.save( MODEL_DIR + exp_dict[exp]["id"] )

  print( "End Experiment Successful: " + exp_dict[exp]["id"] )


