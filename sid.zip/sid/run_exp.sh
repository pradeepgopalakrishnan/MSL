python set_bunch.py 0
python experiment.py 0
python exp_results.py 0