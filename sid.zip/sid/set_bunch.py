import pickle
import os
import argparse
import sys

parser = argparse.ArgumentParser()
parser.add_argument("id", type=str, help="bunch id")
parser.add_argument("--horizon", type=int, help="horizon", default = 20)
parser.add_argument("--total_timesteps", type=int, help="horizon", default = 5000)
args = parser.parse_args()

BUNCH_ID = args.id
BUNCH_DIR = "bunch_" + BUNCH_ID + "/"
MODEL_DIR = BUNCH_DIR + "models/"
DATA_DIR = BUNCH_DIR + "data/"
PLOT_DIR = BUNCH_DIR + "plots/"
HORIZON = args.horizon
TOTAl_TIMESTEPS = args.total_timesteps


if not os.path.exists( BUNCH_DIR[:-1] ):
  os.makedirs( BUNCH_DIR[:-1] )
else:
  print("Bunch already exists, will overwrite")

if not os.path.exists( MODEL_DIR[:-1] ):
  os.makedirs( MODEL_DIR[:-1] )

if not os.path.exists( DATA_DIR[:-1] ):
  os.makedirs( DATA_DIR[:-1] )

if not os.path.exists( PLOT_DIR[:-1] ):
  os.makedirs( PLOT_DIR[:-1] )

exp_dict = {
"E1": {"id": "E1", "room_name": "OneRoom", "horizon": HORIZON, "total_timesteps": TOTAl_TIMESTEPS, "exploration_type": "OM"},
"E2": {"id": "E2", "room_name": "OneRoom", "horizon": HORIZON, "total_timesteps": TOTAl_TIMESTEPS, "exploration_type": "Vanilla"},
"E3": {"id": "E3", "room_name": "OneRoom", "horizon": HORIZON, "total_timesteps": TOTAl_TIMESTEPS, "exploration_type": "PureExplore"} }


bunch_data = {
  "BUNCH_ID": BUNCH_ID,
  "BUNCH_DIR": BUNCH_DIR,
  "MODEL_DIR": MODEL_DIR,
  "DATA_DIR": DATA_DIR,
  "PLOT_DIR": PLOT_DIR,
  "exp_dict": exp_dict
}

with open(BUNCH_DIR + 'bunch' + '.pkl', 'wb') as f: ###
  pickle.dump( bunch_data, f ) ###